from json import loads
from time import sleep
cfg = ""
players={}
FILECFG = "BattleRoyale.cfg"
FILELOGO = "BattleRoyale.log"


with open(FILECFG, "r") as file:
    while True:
        ln=file.readline()
        if not 'set bank_clients_information' in ln:
            cfg+=ln
        if not ln:
            if cfg[-1] == "\n":
                cfg = cfg[:-1]
            break
        if 'set bank_clients_information' in ln:
            pla=ln.split('"')[1]
            pla=pla.split("+")
            for p in pla:
                p=p.split(",")
                players[int(p[0])] = int(p[1])



modif=False
def printpp(players):
    pp = 'set bank_clients_information "'
    for id, mony in players.items():
        pp += f'{id},{mony}+'
    if pp[-1] == "+":
        pp = pp[:-1] + '"'
    else:
        pp += '"'
    with open(FILECFG, "w") as ff:
        ff.write(f"{cfg}\n{pp}")

with open(FILELOGO, "r") as file:
    while 1:
        tx=file.readline()
        if not tx:
            if modif:
                printpp(players)
                modif = False
            sleep(0.1)
        if "IW4MBANK_ALL" in tx:
            for p in loads(tx.split(";")[1]):
                if p["Guid"]!=0:
                    players[p["Guid"]]=p["Money"]
            modif = True
        elif "IW4MBANK" in tx:
            p=tx.split(";")[1:]
            if p[0]!="0":
                players[int(p[0])] = int(p[1][:-1])
            modif = True
